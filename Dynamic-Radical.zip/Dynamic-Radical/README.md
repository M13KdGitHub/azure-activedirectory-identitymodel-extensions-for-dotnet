# Dynamic
Blam!
